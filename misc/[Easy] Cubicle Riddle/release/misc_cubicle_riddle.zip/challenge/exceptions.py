class WrongFormatException(Exception):
    """Base WrongFormatException exception."""
