class CommunicationSystemException(Exception):
    """Base Communication System exception."""
