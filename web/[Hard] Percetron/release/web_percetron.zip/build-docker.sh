#!/bin/sh
docker rm -f web_percetron
docker build -t web_percetron .
docker run --name=web_percetron --rm -p1337:1337 -it web_percetron