#!/bin/bash
docker rm -f web_apexsurvive
docker build --tag=web_apexsurvive .
docker run -p 1337:1337 --rm --name=web_apexsurvive -it web_apexsurvive