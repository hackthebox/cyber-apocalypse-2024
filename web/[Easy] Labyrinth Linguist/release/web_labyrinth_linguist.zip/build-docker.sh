#!/bin/bash
docker rm -f web_labyrinth_linguist
docker build -t web_labyrinth_linguist .
docker run --name=web_labyrinth_linguist --rm -p1337:1337 -it web_labyrinth_linguist