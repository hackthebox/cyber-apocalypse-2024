#!/bin/sh

docker build --tag=web-locktalk . && \
docker run -p 1337:1337 --rm --name=web-locktalk -it web-locktalk