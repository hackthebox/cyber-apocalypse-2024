The player should not try to exploit this binary.
This is just a demo program to help the user
understand the topic and answer the questions.
You will get the flag by answering the questions
on the remote instance. To connect to the IP and PORT:
nc <IP> <PORT> e.g. nc 127.0.0.1 1337
