#!/bin/sh
docker build --tag=gloater .
docker run -it -p 9001:9001 --rm --name=gloater gloater