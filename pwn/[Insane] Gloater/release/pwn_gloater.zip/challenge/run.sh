#!/bin/sh
socat TCP-LISTEN:9001,fork EXEC:"./gloater"
