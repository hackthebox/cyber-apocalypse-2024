#!/bin/sh
docker build --tag=sound_of_silence .
docker run -it -p 1337:1337 --rm --name=sound_of_silence sound_of_silence