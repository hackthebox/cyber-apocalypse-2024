#!/bin/sh
docker build --tag=oracle .
docker run -it -p 9001:9001 --rm --name=oracle oracle
